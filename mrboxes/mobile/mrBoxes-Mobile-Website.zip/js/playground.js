import * as THREE from '../vendor/three.module.js';
import {loadReference} from './robot.js';
import {ReviewLocomotion,FIXED_DT} from './animation.js';
import {MobileController,ThumbStick} from './controls.js';
import {settings} from './settings.js';

const controller=new MobileController();
const movement=new ThumbStick(document.getElementById('move-stick')),viewStick=new ThumbStick(document.getElementById('camera-stick'));
const $=id=>document.getElementById(id),keys={forward:false,left:false,right:false};
// Browser haptics are opt-in; duration approximates impact, not motor strength.
const hapticButton=$('footsteps');
const hapticAvailable=typeof navigator.vibrate==='function';
let haptics=false,previousContacts=[true,true],airborneSpeed=[0,0],lastPulse=-Infinity;
function stopHaptics(){if(hapticAvailable)navigator.vibrate(0);previousContacts=[true,true];airborneSpeed=[0,0];}
if(hapticAvailable){
 hapticButton.disabled=false;hapticButton.textContent='Vibration: Off';hapticButton.title='Optional vibration on foot contact';
 hapticButton.onclick=()=>{
  if(haptics){haptics=false;stopHaptics();hapticButton.setAttribute('aria-pressed','false');hapticButton.textContent='Vibration: Off';return;}
  // A distinct test pulse from the user's tap checks the browser separately from walking.
  haptics=pulse(100);
  hapticButton.setAttribute('aria-pressed',String(haptics));
  hapticButton.textContent=haptics?'Vibration: On':'Vibration blocked';
  hapticButton.title=haptics?'A test pulse was requested. Tap to turn off.':'The browser rejected vibration. Tap to retry.';
 };
}
function pulse(duration){try{return navigator.vibrate(duration)===true;}catch{return false;}}
function updateFootsteps(){
 for(let i=0;i<2;i++){
  const contact=rig.contacts[i];
  if(!contact)airborneSpeed[i]=Math.max(airborneSpeed[i],rig.speed);
  if(contact&&!previousContacts[i]){
   const speed=airborneSpeed[i],now=performance.now();
   if(haptics&&!document.hidden&&speed>.12&&now-lastPulse>205){
    // Shortening pulses suggest a fading impact: 60ms, 50ms gap, 30ms, 50ms gap, 15ms.
    if(!pulse([60,50,30,50,15])){haptics=false;hapticButton.setAttribute('aria-pressed','false');hapticButton.textContent='Vibration blocked';}lastPulse=now;
   }
   airborneSpeed[i]=0;
  }
  previousContacts[i]=contact;
 }
}
window.addEventListener('pagehide',stopHaptics);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.setClearColor(0x172630);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.domElement.tabIndex=0;renderer.domElement.setAttribute('aria-label','Robot movement area. Use the camera and movement thumb controls.');document.body.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.fog=new THREE.Fog(0x172630,27,65);
const camera=new THREE.PerspectiveCamera(43,innerWidth/innerHeight,.05,100);
scene.add(new THREE.HemisphereLight(0xc9e4ff,0x53565c,2.2));
const sun=new THREE.DirectionalLight(0xffecd5,3);sun.position.set(8,14,6);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-22,right:22,top:22,bottom:-22,near:.5,far:50});sun.shadow.bias=-.0002;scene.add(sun);
const material=new THREE.MeshStandardMaterial({color:0x46565f,roughness:.94});
const floor=new THREE.Mesh(new THREE.PlaneGeometry(80,80),material);floor.rotation.x=-Math.PI/2;floor.position.y=-.012;floor.receiveShadow=true;scene.add(floor);
const grid=new THREE.GridHelper(40,40,0x7897a7,0x596e7a);grid.position.y=.002;grid.material.transparent=true;grid.material.opacity=.45;scene.add(grid);
const pad=new THREE.Mesh(new THREE.RingGeometry(2.8,2.84,96),new THREE.MeshBasicMaterial({color:0x84bcc7,side:THREE.DoubleSide}));pad.rotation.x=-Math.PI/2;pad.position.y=.004;scene.add(pad);
function box(w,h,d,x,y,z,color){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color,roughness:.7}));o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);return o}
for(const [x,z] of [[-20,-20],[-20,20],[20,-20],[20,20]]){box(.7,3.2,.7,x,1.6,z,0x263e4c);box(.74,.12,.74,x,2.9,z,0x84c7d6)}
for(const [x,z,w,d] of [[0,-20,40,.15],[0,20,40,.15],[-20,0,.15,40],[20,0,.15,40]])box(w,.13,d,x,.055,z,0x8eafb9);
for(const [name,x,z,color] of [['NORTH',0,19,0x8db5c6],['EAST',19,0,0xc2a373],['SOUTH',0,-19,0x8db5c6],['WEST',-19,0,0xc2a373]]){
 box(1.6,.5,.6,x,.25,z,color);const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#101d28';ctx.fillRect(0,0,512,128);ctx.fillStyle='#d4edf3';ctx.font='500 45px system-ui';ctx.textAlign='center';ctx.fillText(name,256,80);const sign=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c)}));sign.position.set(x,1.4,z);sign.scale.set(2.4,.6,1);scene.add(sign);
}
let orbit=0,elevation=Math.atan2(2,6.8),drag=null,rig,actor,accumulator=0,last=performance.now();
const settingsMenu=$('settings-menu');
let cameraMode='remote';
$('camera-mode').value=cameraMode;
$('camera-mode').onchange=()=>{
 cameraMode=$('camera-mode').value==='flight'?'flight':'remote';
 viewStick.clear();
 $('camera-mode-description').innerHTML=cameraMode==='flight'
  ?'Left (Orbit to the Right) / Right (Orbit to the Left)<br>Up (camera lowers) / Down (camera raises).<br>Release: hold the camera angle.'
  :'Left (Orbit to the Left) / Right (Orbit to the Right)<br>Up (camera raises) / Down (camera lowers).<br>Release: hold the camera angle.';
 $('camera-stick').setAttribute('aria-label',cameraMode==='flight'
  ?'Flight Sim camera control: left orbits right, right orbits left, up lowers, down raises'
  :'Remote Control camera: left orbits left, right orbits right, up raises, down lowers');
};

$('settings-open').onclick=()=>{clearKeys();settingsMenu.showModal();};
$('settings-close').onclick=()=>settingsMenu.close();
settingsMenu.addEventListener('click',e=>{if(e.target===settingsMenu){const b=settingsMenu.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)settingsMenu.close();}});
settingsMenu.addEventListener('close',()=>$('settings-open').focus());
function clearKeys(){stopHaptics();keys.forward=keys.left=keys.right=false;movement.clear();viewStick.clear();controller.reset();drag=null;}
window.addEventListener('keydown',e=>{if(/INPUT|SELECT|BUTTON|TEXTAREA/.test(e.target.tagName))return;const key={KeyW:'forward',KeyA:'left',KeyD:'right'}[e.code];if(key){keys[key]=true;e.preventDefault()}});
window.addEventListener('keyup',e=>{const key={KeyW:'forward',KeyA:'left',KeyD:'right'}[e.code];if(key){keys[key]=false;e.preventDefault()}});
window.addEventListener('blur',clearKeys);document.addEventListener('visibilitychange',()=>{if(document.hidden)clearKeys()});
renderer.domElement.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture(e.pointerId);renderer.domElement.focus()});
renderer.domElement.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;orbit+=(e.clientX-drag.x)*.006;elevation=THREE.MathUtils.clamp(elevation+(e.clientY-drag.y)*.003,settings.minPitch*Math.PI/180,settings.maxPitch*Math.PI/180);drag.x=e.clientX;drag.y=e.clientY});
renderer.domElement.addEventListener('pointerup',()=>{drag=null});renderer.domElement.addEventListener('pointercancel',()=>{drag=null});
function reset(){clearKeys();rig.reset();orbit=0;elevation=Math.atan2(2,6.8);accumulator=0;renderer.domElement.focus()}
$('reset').onclick=()=>{if(actor)reset()};
try{const {root}=await loadReference('./game-robot.glb');actor=new THREE.Group();scene.add(actor);root.scale.setScalar(2.6/3.15);actor.add(root);rig=new ReviewLocomotion(actor,root);renderer.domElement.dataset.armourAttachment=root.getObjectByName('ThighArmourR')?.parent?.name||'missing';actor.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});reset()}catch(e){$('error').textContent='The robot could not load. Refresh to try again.';throw e}
function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,.1);last=now;
 accumulator+=dt;
 while(accumulator>=FIXED_DT){
  if(!actor||document.hidden){accumulator=0;break;}
  const keyboard=keys.forward||keys.left||keys.right;
  let input;
  if(keyboard&&movement.pointer===null){
   controller.reset();
   const forward=keys.forward&&Math.abs(actor.position.x+Math.sin(rig.yaw)*.1)<18&&Math.abs(actor.position.z+Math.cos(rig.yaw)*.1)<18;
   input={...keys,forward,left:keys.left&&!keys.right,right:keys.right&&!keys.left};
  }else{
   input=controller.sample(movement.x,movement.y,rig.yaw,FIXED_DT);
   const nextYaw=rig.yaw+input.yawRate*FIXED_DT;
   const distance=Math.max(rig.speed,input.speed)*FIXED_DT;
   if(Math.abs(actor.position.x+Math.sin(nextYaw)*distance)>18||Math.abs(actor.position.z+Math.cos(nextYaw)*distance)>18){input.speed=0;input.blocked=true;}
  }
  rig.advance(FIXED_DT,input);
  updateFootsteps();
  const rad=Math.PI/180;
  if(Math.hypot(viewStick.x,viewStick.y)>.10){orbit+=(cameraMode==='flight'?-1:1)*viewStick.x*settings.cameraOrbit*rad*FIXED_DT;elevation=THREE.MathUtils.clamp(elevation+(cameraMode==='flight'?-1:1)*viewStick.y*settings.cameraPitch*rad*FIXED_DT,settings.minPitch*rad,settings.maxPitch*rad);}
  accumulator-=FIXED_DT;
 }
 if(!rig)return;
 $('status').textContent=rig.phase+' · '+rig.speed.toFixed(2)+' units/s';
 const target=actor.position.clone().add(new THREE.Vector3(0,1.35,0));camera.position.copy(target).add(new THREE.Vector3(Math.sin(orbit)*7.088*Math.cos(elevation),7.088*Math.sin(elevation),Math.cos(orbit)*7.088*Math.cos(elevation)));camera.lookAt(target);renderer.render(scene,camera);
}requestAnimationFrame(frame);
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
